Framework : Django
Frontend: JavaScript/HTML/CSS
Database: Google Firebase
Storage: Google Firebase Storage

To run project: python manage.py runserver
Client url(should be the given one as it is used in google for redirection) : http://localhost:8000 


Authentication is using google account
