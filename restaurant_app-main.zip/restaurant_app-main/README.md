
Pull the repository then follow the below deployment instructions.

Deployment Steps.

	1. Install gcloud CLI and authenticate the gcloud agent - https://cloud.google.com/sdk/docs/install
	2. Once gcloud cli authentiation is done, deployment can be done using below commands.
	

        cd deployment
	    bash build_image.sh
	    cd kubernetes
		#update the restaurant-app-deployment.yaml file with latest image url 
	    bash deploy.sh
