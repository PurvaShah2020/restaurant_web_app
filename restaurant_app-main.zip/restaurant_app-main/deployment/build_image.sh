imageVersion="latest"
imageRepo="gcr.io/restaurant-347213/restaurant_app"

rm -rf restaurant_app.zip

function login_docker() {
	echo "logging into GCP container registry."
}

function build() {
	pushd  ..
		sha=`git log -1 --pretty=format:%h`
		echo $sha > restaurant.sha
		imageVersion=$imageVersion_$sha
		imagePushTag=$imageRepo:$imageVersion
		rm -rf restaurant_app.zip
		zip -r --exclude=*.git* --exclude=*deployment* --exclude=*.pyc* --exclude=*.swp* --exclude=*pyenv* --exclude=*pyevn* --exclude=*logs* --exclude=*__pycache__* restaurant_app.zip ./	
		cp restaurant_app.zip ./deployment

	popd
	
	docker build -t $imageRepo .
}

function pushImage() {
	login_docker 
	docker tag $imageRepo $imagePushTag
	docker push $imagePushTag
}


function main() {
	build
	if [ "$?" == "0" ];then
		echo "Build success, pushing.. $imagePushTag"
		pushImage
	else
		echo "Build failed."
	fi
}

main
