
function get_credentials() {
	echo "Getting credentials."
	gcloud container clusters get-credentials restaurant-app-cluster-1 --zone asia-south1-a --project restaurant-347213
}

function deploy_application() {
	echo "Deploying application."
	kubectl apply -f restaurant-app-deployment.yaml
	kubectl get deployment
	kubectl get pods
}

function deploy_load_balancer() {
	echo "Deploying load-balancer."
	kubectl apply -f restaurant-app-loadbalancer-service.yaml
	kubectl get service
}


function main() {
	get_credentials
	deploy_application
}


main
