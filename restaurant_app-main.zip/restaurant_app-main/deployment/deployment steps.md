Restaurant App - Deployment Setup Steps

1. Create git repo and push the unzipped files to it. To access the git repo clone the repo using SSH keys attched.
    REPO URL : git@bitbucket.org:sreenathpgs/restaurant_app.git
    
2. Create Dockerfile for the app - Please find the docker file in the repo (./deployment/Dockerfile)

3. Create a docker image using the dockerfile.

4. Enable container registry in GCP.

5. Push the created docker image to the container registry using authentication token (JSON token).

6. Enable kubernetes engine in GCP.

7. Create kubernetes config file for setting up clusters - Please find kubernetes config files in the repo (./deployment/kubernetes/restaurant-app-deployment.yaml).

8. Create kubernetes config file to configure a loadbalancer for the cluster - Please find kubernetes config files in the repo (./deployment/kubernetes/restaurant-app-loadbalancer-service.yaml).

9. Apply (deploy) the config files on GKE to create clusters and loadbalancer services in GCP.
