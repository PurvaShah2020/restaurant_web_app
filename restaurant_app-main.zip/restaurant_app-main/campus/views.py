
from operator import ge
from re import template
import requests 
from django.shortcuts import render
from django.views import generic
from django.urls.base import reverse_lazy
from django.shortcuts import redirect, render
from django.contrib.auth import logout
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.mixins import LoginRequiredMixin
# Create your views here.


class Homepage(LoginRequiredMixin, generic.TemplateView):
    template_name="homepage.html"
    login_url = reverse_lazy('login')

    # def get(self, request, *args, **kwargs):
    #     if not request.user.is_authenticated:
    #         return reverse_lazy(redirect('login'))
    #     return super().get(self, request, *args, **kwargs)


class RestaurantList(LoginRequiredMixin, generic.TemplateView):
    template_name="restaurant.html"
    login_url = reverse_lazy('login')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        campus = self.request.GET.get('campus')
        if not campus:
            campus = 'campus1'
        response = requests.get(f"https://restaurantapp-9b57e-default-rtdb.firebaseio.com/campus_list/{campus}/restaurants.json")
        context["rest_list"] = response.json()
        context["cam"] = campus
        print(context["rest_list"])
        return context


class ReviewsList(LoginRequiredMixin, generic.TemplateView):
    template_name="reviews.html"
    login_url = reverse_lazy('login')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        restaurant = self.request.GET.get('restaurant')
        campus = self.request.GET.get('campus')
        if not campus:
            campus = 'campus1'
        if not restaurant:
            restaurant = 'restaurant'
        response = requests.get(f"https://restaurantapp-9b57e-default-rtdb.firebaseio.com/campus_list/{campus}/restaurants/{restaurant}/Review.json")
        context["rest_list"] = response.json()
        context["cam"] = campus
        context["rest"] = restaurant

        return context


class AddReview(LoginRequiredMixin, generic.View):
    login_url = reverse_lazy('login')

    def post(self, *args, **kwargs):
        review = self.request.POST.get('review')
        filename = self.request.POST.get('filename')
        campus = self.request.POST.get('campus')
        restaurant = self.request.POST.get('restaurant')
        img = self.request.POST.get('image_up', "")
        if not campus:
            campus = 'campus1'
        if not restaurant:
            restaurant = 'restaurant'
        # response = requests.patch(f"https://restaurantdb-88f89-default-rtdb.firebaseio.com/campus_list/{campus}/restaurants/{restaurant}/Review.json", json={name : review})
        rev_dict = {
                review: filename
        }

        print("self.request.user", self.request.user)
        response = requests.patch(f"https://restaurantapp-9b57e-default-rtdb.firebaseio.com/campus_list/{campus}/restaurants/{restaurant}/Review/{str(self.request.user)}.json", json=rev_dict)
        print(response.text)
        return redirect(reverse_lazy('restaurant'))

    
class LoginView(generic.TemplateView):
    template_name="login.html"

    def post(self, *args, **kwargs):
        # API_KEY = "AIzaSyCNvO1OZmnOSqIgO5Xh39g630uG9SB_2d4"
        # data = {"email":"[purvashah2020@gmail.com]","password":"[123purva]","returnSecureToken":True}
        # url = f'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={API_KEY}'
        # response = requests.post(url, json=data)
        # print("reg:", response)
        email = self.request.POST.get("email")
        password = self.request.POST.get("password")
        try:
            user_obj = User.objects.get(email=email)
            print("hererereerererre",user_obj)
            user = authenticate(username=user_obj.username, password=password)
            print("after authentication", )
            if user:
                login(self.request, user)
                print("userrre", user, "post",self.request.POST)
            else:
                messages.error(self.request, "Invalid credentials.")
        except Exception as e:
            print(e)
            messages.error(self.request, "Invalid credentials.")
        return redirect(reverse_lazy('homepage'))


class LogoutView(generic.View):
    
    def get(self, *args, **kwargs):
        print("getttt logout")
        logout(self.request)
        # self.request.user.is_authenticated = False
        return redirect(reverse_lazy('login'))


class Register(generic.TemplateView):
    template_name = "register.html"

    def post(self, *args, **kwargs):
        # API_KEY = "AIzaSyCNvO1OZmnOSqIgO5Xh39g630uG9SB_2d4"
        # data = {"email":"[purvashah2020@gmail.com]","password":"[123purva]","returnSecureToken":True}
        # url = f'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={API_KEY}'
        # response = requests.post(url, json=data)
        # print("reg:", response)
        name = self.request.POST.get("name")
        email = self.request.POST.get("email")
        password = self.request.POST.get("password")
        con_password = self.request.POST.get("con_password")
        if User.objects.filter(username=name).exists():
            messages.error(self.request, "Username already exists!.")
            return redirect(reverse_lazy('login'))
        if User.objects.filter(email=email).exists():
            messages.error(self.request, "Email already exists!.")
            return redirect(reverse_lazy('login'))
        if password != con_password:
            messages.error(self.request, "Password and Confirm password should be same")
            return redirect(reverse_lazy('login'))
        user_obj = User.objects.create(username=name, first_name=name, email=email)
        user_obj = User.objects.get(username=name)
        user_obj.set_password(password)
        user_obj.save()
        user = authenticate(username=user_obj.username, password=password)
        print("after authentication", )
        if user:
            login(self.request, user)
            print("userrre", user, "post",self.request.POST)
        else:
            messages.error(self.request, "Invalid credentials.")
        messages.success(self.request, "Successfully registered.")
        return redirect(reverse_lazy('homepage'))


